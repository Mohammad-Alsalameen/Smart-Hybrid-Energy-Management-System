# app.py — Strong Results Dashboard (NO Plotly) | Dark | English
# -----------------------------------------------------------------------
# Required files in SAME folder as app.py:
#   - dataset_clean.csv
#   - optimization_results_eff09.csv
#   - rule_based_results_eff09.csv
#   - comparison_summary_eff09.csv
#   - evaluation_matrices_FIXED_objective.csv
#
# Run:
#   streamlit run app.py

import os
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

# ---------------------------
# Robust ROOT
# ---------------------------
try:
    ROOT = os.path.dirname(os.path.abspath(__file__))
except NameError:
    ROOT = os.getcwd()

FILES = {
    "dataset": os.path.join(ROOT, "dataset_clean.csv"),
    "opt": os.path.join(ROOT, "optimization_results_eff09.csv"),
    "rule": os.path.join(ROOT, "rule_based_results_eff09.csv"),
    "summary": os.path.join(ROOT, "comparison_summary_eff09.csv"),
    "eval": os.path.join(ROOT, "evaluation_matrices_FIXED_objective.csv"),
}

def must_exist(p):
    return p and os.path.exists(p) and os.path.isfile(p)

missing = [k for k, p in FILES.items() if not must_exist(p)]

st.set_page_config(page_title="Energy Results Dashboard", page_icon="⚡", layout="wide")

# ---------------------------
# Dark UI
# ---------------------------
st.markdown(
    """
    <style>
      html, body, [class*="css"] { direction: ltr; }
      .stApp {
        background: radial-gradient(1200px 700px at 45% 0%, #141a27 0%, #0b0f16 55%, #06080d 100%);
        color: #e9eef6;
      }
      h1,h2,h3,h4 { color: #e9eef6; }
      .muted { opacity: .82; }
      .card {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 16px;
        padding: 14px 16px;
      }
      .kpi { font-size: 1.8rem; font-weight: 800; margin-top: 4px; }
      .label { opacity: .86; font-size: .95rem; }
      .hr { height:1px; background: rgba(255,255,255,0.10); margin: 14px 0; }
      .winner {
        background: rgba(46, 204, 113, 0.16);
        border: 1px solid rgba(46, 204, 113, 0.30);
        border-radius: 16px;
        padding: 12px 14px;
      }
      .warn {
        background: rgba(241, 196, 15, 0.14);
        border: 1px solid rgba(241, 196, 15, 0.26);
        border-radius: 16px;
        padding: 12px 14px;
      }
      .bad {
        background: rgba(231, 76, 60, 0.14);
        border: 1px solid rgba(231, 76, 60, 0.26);
        border-radius: 16px;
        padding: 12px 14px;
      }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown("## ⚡ Energy Results Dashboard")
st.markdown('<div class="muted">Clean non-live dashboard: RL ranking + OPT vs Rule-based comparison</div>', unsafe_allow_html=True)
st.markdown('<div class="hr"></div>', unsafe_allow_html=True)

if missing:
    st.markdown('<div class="bad"><b>Missing files in the app folder:</b></div>', unsafe_allow_html=True)
    for k in missing:
        st.write("-", os.path.basename(FILES[k]))
    st.stop()

# ---------------------------
# Loaders
# ---------------------------
@st.cache_data(show_spinner=False)
def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    return df

dataset = load_csv(FILES["dataset"])
opt = load_csv(FILES["opt"])
rule = load_csv(FILES["rule"])
summary = load_csv(FILES["summary"])
eval_df = load_csv(FILES["eval"])

# parse timestamps
for df in (dataset, opt, rule):
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df.dropna(subset=["timestamp"], inplace=True)
        df.sort_values("timestamp", inplace=True)

# ---------------------------
# Helpers
# ---------------------------
def fmt(x, digits=3, suffix=""):
    try:
        x = float(x)
        if np.isnan(x): return "—"
        return f"{x:,.{digits}f}{suffix}"
    except Exception:
        return "—"

def kpi_card(col, label, value):
    with col:
        st.markdown(
            f"""
            <div class="card">
              <div class="label">{label}</div>
              <div class="kpi">{value}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

def safe_sum(df: pd.DataFrame, col: str):
    if col not in df.columns:
        return np.nan
    return float(pd.to_numeric(df[col], errors="coerce").fillna(0).sum())

def safe_mean(df: pd.DataFrame, col: str):
    if col not in df.columns:
        return np.nan
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    return float(s.mean()) if not s.empty else np.nan

def safe_max(df: pd.DataFrame, col: str):
    if col not in df.columns:
        return np.nan
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    return float(s.max()) if not s.empty else np.nan

def filter_by_date(df: pd.DataFrame, start_date, end_date, ts="timestamp"):
    d = df.copy()
    if ts in d.columns:
        d = d[(d[ts].dt.date >= start_date) & (d[ts].dt.date <= end_date)]
    return d

# ---------------------------
# Sidebar
# ---------------------------
st.sidebar.header("Controls")
page = st.sidebar.radio("Page", ["RL Algorithms", "OPT vs Rule-Based"], index=0)

# Date range from dataset timestamps
if "timestamp" in dataset.columns and not dataset.empty:
    min_t = dataset["timestamp"].min()
    max_t = dataset["timestamp"].max()
    start_date, end_date = st.sidebar.date_input(
        "Date range",
        value=(min_t.date(), max_t.date()),
        min_value=min_t.date(),
        max_value=max_t.date()
    )
else:
    start_date, end_date = None, None
    st.sidebar.info("No timestamp in dataset_clean.csv — date filter disabled.")

# =========================================================
# Page 1: RL Algorithms (Ranking + details)
# =========================================================
if page == "RL Algorithms":
    st.markdown("### 🧠 RL Algorithms (PPO / DQN / TD3)")
    st.markdown('<div class="muted">Data source: evaluation_matrices_FIXED_objective.csv</div>', unsafe_allow_html=True)

    if "Algorithm" not in eval_df.columns:
        st.error("Missing column: Algorithm")
        st.stop()

    e = eval_df.copy()
    # numeric convert
    for c in e.columns:
        if c != "Algorithm":
            e[c] = pd.to_numeric(e[c], errors="coerce")

    # Create ranking score:
    # primary: Objective Gap %, secondary: MAE
    if "Objective Gap %" in e.columns:
        tmp = e.dropna(subset=["Objective Gap %"]).copy()
    else:
        tmp = e.copy()

    sort_cols = []
    if "Objective Gap %" in tmp.columns: sort_cols.append("Objective Gap %")
    if "MAE(cost_step RL vs OPT)" in tmp.columns: sort_cols.append("MAE(cost_step RL vs OPT)")

    winner = None
    if sort_cols:
        tmp2 = tmp.sort_values(sort_cols, ascending=True)
        if not tmp2.empty:
            winner = str(tmp2.iloc[0]["Algorithm"])

            reasons = []
            if "Objective Gap %" in tmp2.columns: reasons.append("lowest Objective Gap %")
            if "MAE(cost_step RL vs OPT)" in tmp2.columns: reasons.append("lowest MAE (tie-breaker)")

            st.markdown(
                f"""
                <div class="winner">
                  ✅ <b>Best Algorithm:</b> {winner}<br/>
                  <span class="muted">Reason: {", ".join(reasons)}</span>
                </div>
                """,
                unsafe_allow_html=True
            )
            st.markdown('<div class="hr"></div>', unsafe_allow_html=True)

    # Compact table (no duplicates / no huge table)
    keep_cols = [
        "Algorithm",
        "Total Objective RL (JOD)", "Total Objective OPT (JOD)", "Objective Gap %",
        "Total Grid Cost RL (JOD)", "Total Grid Cost OPT (JOD)", "Grid Gap %",
        "MAE(cost_step RL vs OPT)", "RMSE(cost_step RL vs OPT)",
        "Equivalent Full Cycles (EFC) RL", "Matched OPT hours"
    ]
    cols = [c for c in keep_cols if c in e.columns]
    comp = e[cols].copy()

    st.markdown("#### 📊 Compact Comparison Table")
    st.dataframe(comp, use_container_width=True, height=260)

    # Pick algorithm -> show details
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    algos = e["Algorithm"].astype(str).tolist()
    algo_pick = st.selectbox("Select algorithm", algos, index=0)
    row = e[e["Algorithm"].astype(str) == str(algo_pick)].iloc[0].to_dict()

    c1, c2, c3, c4 = st.columns(4)
    kpi_card(c1, "Objective Gap %", fmt(row.get("Objective Gap %", np.nan), 3, " %"))
    kpi_card(c2, "Grid Gap %", fmt(row.get("Grid Gap %", np.nan), 3, " %"))
    kpi_card(c3, "MAE (step cost)", fmt(row.get("MAE(cost_step RL vs OPT)", np.nan), 5))
    kpi_card(c4, "EFC (RL)", fmt(row.get("Equivalent Full Cycles (EFC) RL", np.nan), 4))

    # Small charts (not huge)
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    st.markdown("#### 📈 Small Charts")

    colA, colB = st.columns(2)

    if "Objective Gap %" in e.columns:
        with colA:
            fig, ax = plt.subplots(figsize=(6, 3))
            ax.bar(e["Algorithm"].astype(str).values, e["Objective Gap %"].values)
            ax.set_title("Objective Gap % (lower is better)")
            ax.grid(True, axis="y", alpha=0.25)
            st.pyplot(fig, use_container_width=True)

    if "Grid Gap %" in e.columns:
        with colB:
            fig, ax = plt.subplots(figsize=(6, 3))
            ax.bar(e["Algorithm"].astype(str).values, e["Grid Gap %"].values)
            ax.set_title("Grid Gap % (lower is better)")
            ax.grid(True, axis="y", alpha=0.25)
            st.pyplot(fig, use_container_width=True)

# =========================================================
# Page 2: OPT vs Rule-Based (Clean KPIs + bar compare + 1 plot)
# =========================================================
else:
    st.markdown("### ⚖️ OPT vs Rule-Based")
    st.markdown('<div class="muted">Clean KPIs + strong bar comparison + one clear trend plot</div>', unsafe_allow_html=True)

    if start_date and end_date and "timestamp" in dataset.columns:
        opt_f = filter_by_date(opt, start_date, end_date)
        rule_f = filter_by_date(rule, start_date, end_date)
        dataset_f = filter_by_date(dataset, start_date, end_date)
    else:
        opt_f, rule_f, dataset_f = opt.copy(), rule.copy(), dataset.copy()

    # KPIs
    rb_cost = safe_sum(rule_f, "cost_JOD")
    opt_cost = safe_sum(opt_f, "cost_JOD")
    savings = rb_cost - opt_cost if (np.isfinite(rb_cost) and np.isfinite(opt_cost)) else np.nan
    savings_pct = (savings / rb_cost * 100.0) if (np.isfinite(savings) and np.isfinite(rb_cost) and rb_cost != 0) else np.nan

    rb_imp = safe_sum(rule_f, "grid_import_kWh")
    opt_imp = safe_sum(opt_f, "grid_import_kWh")
    rb_exp = safe_sum(rule_f, "grid_export_kWh")
    opt_exp = safe_sum(opt_f, "grid_export_kWh")

    batt_cap = safe_max(dataset_f, "battery_capacity_kWh")
    tariff_avg = safe_mean(dataset_f, "tariff_JOD_per_kWh")

    # Battery quality: EFC rule (max), EFC opt (estimated)
    efc_rule = safe_max(rule_f, "equivalent_full_cycles")

    ch_opt = safe_sum(opt_f, "charge_into_batt_kWh") if "charge_into_batt_kWh" in opt_f.columns else np.nan
    dis_opt = safe_sum(opt_f, "discharge_from_batt_kWh") if "discharge_from_batt_kWh" in opt_f.columns else np.nan
    efc_opt = ((ch_opt + dis_opt) / (2.0 * batt_cap)) if (np.isfinite(ch_opt) and np.isfinite(dis_opt) and np.isfinite(batt_cap) and batt_cap > 0) else np.nan

    c1, c2, c3, c4 = st.columns(4)
    kpi_card(c1, "Total Cost (Rule)", fmt(rb_cost, 3, " JOD"))
    kpi_card(c2, "Total Cost (OPT)", fmt(opt_cost, 3, " JOD"))
    kpi_card(c3, "Savings (Rule - OPT)", fmt(savings, 3, " JOD"))
    kpi_card(c4, "Savings % vs Rule", fmt(savings_pct, 2, " %"))

    c5, c6, c7, c8 = st.columns(4)
    kpi_card(c5, "Grid Import (Rule vs OPT)", f"{fmt(rb_imp,2)} vs {fmt(opt_imp,2)} kWh")
    kpi_card(c6, "Grid Export (Rule vs OPT)", f"{fmt(rb_exp,2)} vs {fmt(opt_exp,2)} kWh")
    kpi_card(c7, "Battery Capacity", fmt(batt_cap, 2, " kWh"))
    kpi_card(c8, "Avg Tariff", fmt(tariff_avg, 4, " JOD/kWh"))

    # Winner statement
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    if np.isfinite(savings):
        if savings > 0:
            st.markdown('<div class="winner">✅ OPT is better (lower total cost) for the selected range.</div>', unsafe_allow_html=True)
        elif savings < 0:
            st.markdown('<div class="warn">⚠️ Rule looks better than OPT in this range — double-check constraints or data.</div>', unsafe_allow_html=True)
        else:
            st.info("Equal results in this range.")

    # Strong bar comparison (cost/import/export)
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    st.markdown("#### 📊 Strong Comparison (Bar)")

    labels = ["Total Cost (JOD)", "Grid Import (kWh)", "Grid Export (kWh)"]
    rule_vals = [rb_cost, rb_imp, rb_exp]
    opt_vals  = [opt_cost, opt_imp, opt_exp]

    fig, ax = plt.subplots(figsize=(10, 3.6))
    x = np.arange(len(labels))
    w = 0.36
    ax.bar(x - w/2, rule_vals, width=w, label="Rule-Based")
    ax.bar(x + w/2, opt_vals, width=w, label="OPT")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=0)
    ax.set_title("Rule-Based vs OPT (Key Totals)")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    st.pyplot(fig, use_container_width=True)

    # Battery quality box (simple and explainable)
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    st.markdown("#### 🔋 Battery Quality (Simple)")

    colA, colB = st.columns(2)
    kpi_card(colA, "EFC (Rule - from file)", fmt(efc_rule, 4))
    kpi_card(colB, "EFC (OPT - estimated)", fmt(efc_opt, 4))

    st.caption("EFC = Equivalent Full Cycles. Lower EFC usually means less battery stress (longer life).")
    st.caption("EFC is computed over the selected date range (higher = more battery usage/stress).")


    # ONE clear trend plot: Daily cost
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    st.markdown("#### 📈 Trend (Daily Cost Only)")

    if ("timestamp" in opt_f.columns) and ("timestamp" in rule_f.columns) and ("cost_JOD" in opt_f.columns) and ("cost_JOD" in rule_f.columns):
        opt_day = opt_f[["timestamp", "cost_JOD"]].copy()
        rule_day = rule_f[["timestamp", "cost_JOD"]].copy()
        opt_day["day"] = opt_day["timestamp"].dt.floor("D")
        rule_day["day"] = rule_day["timestamp"].dt.floor("D")
        opt_daily = opt_day.groupby("day")["cost_JOD"].sum().reset_index()
        rule_daily = rule_day.groupby("day")["cost_JOD"].sum().reset_index()

        fig, ax = plt.subplots(figsize=(10, 3.2))
        ax.plot(rule_daily["day"], rule_daily["cost_JOD"], label="Rule-Based", linewidth=1.8)
        ax.plot(opt_daily["day"], opt_daily["cost_JOD"], label="OPT", linewidth=1.8)
        ax.set_title("Daily Cost (JOD)")
        ax.grid(True, alpha=0.25)
        ax.legend()
        st.pyplot(fig, use_container_width=True)
    else:
        st.info("Need timestamp + cost_JOD in both OPT and Rule files to plot daily cost.")

    # Show summary table (formatted) — ONLY ONCE
    st.markdown('<div class="hr"></div>', unsafe_allow_html=True)
    st.markdown("#### 📌 Summary Table (comparison_summary_eff09.csv)")

    sum_df = summary.copy()
    st.dataframe(sum_df, use_container_width=True, height=280)
